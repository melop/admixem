dat <- read.table("grepsumculture.txt", header=T);
datPop1 <- dat[dat$Pop==1,]
datPop2 <- dat[dat$Pop==2,]
datPop3 <- dat[dat$Pop==3,]

datMerge <- merge(datPop1 , datPop2, by=c("Rep" , "Gen"));
datMerge <- merge(datMerge , datPop3, by=c("Rep" , "Gen"));

oLayout <- matrix(c(1,1,1,2), 1, 4, byrow = TRUE);
layout(oLayout);
plot(datMerge$Gen, abs(datMerge$AllMean.x - datMerge$AllMean.y) , cex=2, pch=20, col=rgb(1,1/4,0,1/8), xlab="Generation", ylab="Culture differences", cex.lab=1.5, cex.axis=1.2)
oHist <- hist(abs(datMerge[datMerge$Gen>2500, "AllMean.x"] - datMerge[datMerge$Gen>2900, "AllMean.y"]) , plot=F, breaks=20, freq=T);
oHist$counts<-oHist$counts/sum(oHist$counts)
barplot(oHist$counts, horiz = T,  col="orange", ylab="Distribution of Culture differences at Generation 3000", cex.lab=1.2, cex.axis=1.2); #xlab="Which Sex Chromosome", 